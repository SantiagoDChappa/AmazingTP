package complejidad;

public class main {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			AB<Integer> arbolBinario = new AB<Integer>();
			
			arbolBinario.agregar(15);
			arbolBinario.agregar(20);
			System.out.println(arbolBinario.cantNodos());
			arbolBinario.agregar(15);
			arbolBinario.agregar(20);
			arbolBinario.agregar(15);
			arbolBinario.agregar(20);
			arbolBinario.agregar(15);
			arbolBinario.agregar(20);
			System.out.println(arbolBinario.cantNodos());
		}   
}

