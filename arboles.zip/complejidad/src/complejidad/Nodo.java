package complejidad;

	public class Nodo<T>{
        private T info;
        private Nodo<T> der;
        private Nodo<T> izq;
    
        public Nodo(T info){
            this.info = info;
        }
    
        @Override
        public String toString(){
            return info.toString();
        }

        public Nodo getIzq(){
            return this.izq;
        }
        
        public Nodo getDer(){
            return this.der;
        }

        public void setIzq(Nodo nodo){
            this.izq = nodo;
        }
        
        public void setDer(Nodo nodo){
            this.der = nodo;
        }
}
