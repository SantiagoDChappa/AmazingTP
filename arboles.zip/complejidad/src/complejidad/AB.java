package complejidad;

	public class AB<T> {
        private Nodo<T> raiz;
		private Integer cantNodos;
        
    public AB(){
        this.raiz = null;
        this.cantNodos = 0;
    }
     
    public void agregar(T elem){
        Nodo<T> nuevo = new Nodo<T>(elem);
        if(raiz == null){
            raiz = nuevo;
            cantNodos++;
        }else{
            agregar(raiz, nuevo);
        }
    }

    public void agregar(Nodo<T> padre, Nodo<T> hijo){
        if(padre.getIzq() == null){
            padre.setIzq(hijo);
            cantNodos++;
        }else if(padre.getDer() == null){
        	padre.setDer(hijo);
        	cantNodos++;
        }else {
        	agregar(padre.getIzq(), hijo);
        }
    }

    public Integer cantNodos(){
        return cantNodos;
    }

    public Nodo<T> buscar(T elem){
         if(raiz == null){
            return null;
         }else{
            buscar(raiz, elem);
         }
    }
    public Nodo<T> buscar(Nodo<T> nodo,T elem){
         if(nodo.toString().equals(elem)){
            return nodo;
         }else{
            Nodo<T> izq = null;
            Nodo<T> der = null;
            if(nodo.getIzq() != null){
                izq = buscar(nodo.getIzq(), elem);
            }
            if(nodo.getDer() != null){
                der = buscar(nodo.getDer(), elem);
            }
            if(izq != null){
                return izq;
            }else{
                return der;
            }
         }
    }
}
